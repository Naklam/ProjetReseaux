Pour lancer les VMs, faire dans un terminal:
bash VagrantUp.sh

Pour detruire les VMs, faire dans un terminal:
bash destroy.sh

Le code est dans le fichier 'Prog'( les lignes de commandes d'excecutione t compilation sont dans les fichiers .c correcpondant)
