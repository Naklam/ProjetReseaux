# ProjetReseaux

VM3-6bis: Vm defectueuse, à analyser pour eviter que le probleme ne se reproduise.

VM2-6: Route vers VM1-6 non reconnu dans le config.sls mais le add route fonctionne(chercher la raison).
